﻿using UnityEngine;
using System.IO;
using System.Text;
using System;


public class CrossPlatform {
    public virtual string SendPlatformMsg(string msg)
    {
        //Debug.LogError(msg);
        return "";
    }
}
